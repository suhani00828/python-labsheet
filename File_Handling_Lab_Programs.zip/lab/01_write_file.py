# Program 1: Create and write text into a file
try:
    with open("sample.txt", "w") as f:       # "w" creates the file (overwrites if it exists)
        f.write("Python is a popular programming language.\n")
        f.write("It is easy to learn and powerful to use.\n")
        f.write("\n")
        f.write("File handling in Python is simple.\n")
        f.write("Python supports text, CSV and binary files.\n")
        f.write("\n")
        f.write("Learning Python is fun.\n")
    print("File written successfully.")
except IOError as e:
    print("Error:", e)
