# Program 2: Read the entire content of a text file
try:
    with open("sample.txt", "r") as f:       # open in read mode
        content = f.read()                   # read whole file as one string
    print(content)
except FileNotFoundError:
    print("File not found.")
