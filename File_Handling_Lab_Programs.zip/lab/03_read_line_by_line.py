# Program 3: Read a file line by line
try:
    with open("sample.txt", "r") as f:
        for line in f:                       # file object yields one line at a time
            print(line.rstrip())             # rstrip removes the trailing newline
except FileNotFoundError:
    print("File not found.")
