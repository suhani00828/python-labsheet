# Program 4: Count the number of words in a text file
try:
    with open("sample.txt", "r") as f:
        text = f.read()
    words = text.split()                     # split on any whitespace
    print("Total words:", len(words))
except FileNotFoundError:
    print("File not found.")
