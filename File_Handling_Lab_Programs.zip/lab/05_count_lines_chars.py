# Program 5: Count the number of lines and characters in a file
try:
    with open("sample.txt", "r") as f:
        lines = f.readlines()                # list of all lines
    chars = sum(len(line) for line in lines) # characters (including newlines)
    print("Lines     :", len(lines))
    print("Characters:", chars)
except FileNotFoundError:
    print("File not found.")
