# Program 6: Display only even-numbered lines from a file
try:
    with open("sample.txt", "r") as f:
        for num, line in enumerate(f, start=1):   # line numbers start at 1
            if num % 2 == 0:                      # keep even line numbers only
                print(num, ":", line.rstrip())
except FileNotFoundError:
    print("File not found.")
