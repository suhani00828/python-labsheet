# Program 7: Write multiple lines of user input into a file
try:
    n = int(input("How many lines do you want to enter? "))
    with open("user_input.txt", "w") as f:
        for i in range(n):
            line = input(f"Enter line {i + 1}: ")
            f.write(line + "\n")             # write each line with newline
    print("Saved to user_input.txt")
except ValueError:
    print("Please enter a valid number.")
except IOError as e:
    print("Error:", e)
