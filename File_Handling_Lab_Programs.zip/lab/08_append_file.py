# Program 8: Append new content to an existing file
try:
    text = input("Enter text to append: ")
    with open("sample.txt", "a") as f:       # "a" = append mode, keeps old content
        f.write(text + "\n")
    print("Content appended.")
except IOError as e:
    print("Error:", e)
