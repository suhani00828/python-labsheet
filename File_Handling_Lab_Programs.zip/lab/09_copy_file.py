# Program 9: Copy the contents of one file into another
try:
    with open("sample.txt", "r") as src, open("copy.txt", "w") as dst:
        dst.write(src.read())                # read source, write to destination
    print("File copied to copy.txt")
except FileNotFoundError:
    print("Source file not found.")
