# Program 10: Read a file and convert its content to uppercase
try:
    with open("sample.txt", "r") as f:
        content = f.read()
    print(content.upper())                   # display in uppercase
    with open("upper.txt", "w") as f:        # also save the result
        f.write(content.upper())
except FileNotFoundError:
    print("File not found.")
