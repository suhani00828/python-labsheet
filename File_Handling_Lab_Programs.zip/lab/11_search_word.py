# Program 11: Search for a particular word in a file
word = input("Enter word to search: ").lower()
try:
    found = False
    with open("sample.txt", "r") as f:
        for num, line in enumerate(f, start=1):
            if word in line.lower().split() or word in line.lower():
                print(f"Found on line {num}: {line.rstrip()}")
                found = True
    if not found:
        print("Word not found.")
except FileNotFoundError:
    print("File not found.")
