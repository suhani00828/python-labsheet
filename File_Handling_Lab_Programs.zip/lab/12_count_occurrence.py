# Program 12: Count the occurrence of a specific word in a file
word = input("Enter word to count: ").lower()
try:
    with open("sample.txt", "r") as f:
        words = f.read().lower().split()
    # strip punctuation from each word before comparing
    count = sum(1 for w in words if w.strip(".,;:!?\"'") == word)
    print(f"'{word}' occurs {count} time(s).")
except FileNotFoundError:
    print("File not found.")
