# Program 13: Read numbers from a file and display their sum and average
try:
    with open("numbers.txt", "r") as f:
        nums = [float(line) for line in f if line.strip()]   # skip blank lines
    if nums:
        print("Sum    :", sum(nums))
        print("Average:", sum(nums) / len(nums))
    else:
        print("File has no numbers.")
except FileNotFoundError:
    print("File not found.")
except ValueError:
    print("File contains a non-numeric value.")
