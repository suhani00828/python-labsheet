# Program 14: Display the longest line in a file
try:
    with open("sample.txt", "r") as f:
        lines = [line.rstrip() for line in f]
    longest = max(lines, key=len)            # line with maximum length
    print("Longest line:", longest)
    print("Length      :", len(longest))
except FileNotFoundError:
    print("File not found.")
except ValueError:
    print("File is empty.")
