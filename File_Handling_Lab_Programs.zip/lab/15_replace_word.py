# Program 15: Replace a word in a file with another word
old = input("Word to replace: ")
new = input("Replace with   : ")
try:
    with open("sample.txt", "r") as f:
        content = f.read()
    content = content.replace(old, new)      # replace all occurrences
    with open("sample.txt", "w") as f:       # write the modified text back
        f.write(content)
    print("Replacement done.")
except FileNotFoundError:
    print("File not found.")
