# Program 16: Display the first and last lines of a file
try:
    with open("sample.txt", "r") as f:
        lines = [l.rstrip() for l in f if l.strip()]   # ignore blank lines
    print("First line:", lines[0])
    print("Last line :", lines[-1])
except FileNotFoundError:
    print("File not found.")
except IndexError:
    print("File is empty.")
