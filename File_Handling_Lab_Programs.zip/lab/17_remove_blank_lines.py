# Program 17: Remove blank lines from a file
try:
    with open("sample.txt", "r") as f:
        lines = f.readlines()
    with open("no_blank.txt", "w") as f:
        for line in lines:
            if line.strip():                 # keep only non-empty lines
                f.write(line)
    print("Blank lines removed -> no_blank.txt")
except FileNotFoundError:
    print("File not found.")
