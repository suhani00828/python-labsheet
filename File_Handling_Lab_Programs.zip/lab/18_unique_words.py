# Program 18: Store only unique words into another file
try:
    with open("sample.txt", "r") as f:
        words = f.read().lower().split()
    unique = []
    for w in words:
        w = w.strip(".,;:!?\"'")             # remove punctuation
        if w and w not in unique:            # keep first occurrence only
            unique.append(w)
    with open("unique_words.txt", "w") as f:
        f.write("\n".join(unique))
    print(len(unique), "unique words saved to unique_words.txt")
except FileNotFoundError:
    print("File not found.")
