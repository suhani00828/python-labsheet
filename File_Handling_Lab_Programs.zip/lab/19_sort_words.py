# Program 19: Sort all words alphabetically and save to a new file
try:
    with open("sample.txt", "r") as f:
        words = [w.strip(".,;:!?\"'").lower() for w in f.read().split()]
    words = sorted(w for w in words if w)    # alphabetical order
    with open("sorted_words.txt", "w") as f:
        f.write("\n".join(words))
    print("Sorted words saved to sorted_words.txt")
except FileNotFoundError:
    print("File not found.")
