# Program 20: Merge two text files into a third file
try:
    with open("merged.txt", "w") as out:
        for name in ("file1.txt", "file2.txt"):
            with open(name, "r") as f:
                out.write(f.read())          # append each file's content
    print("Files merged into merged.txt")
except FileNotFoundError as e:
    print("File not found:", e)
