# Program 21: Create and write data into a CSV file
import csv
data = [["Name", "Roll", "Marks", "Age"],
        ["Amit", 101, 85, 20],
        ["Riya", 102, 92, 19],
        ["Karan", 103, 78, 21],
        ["Sneha", 104, 92, 20]]
try:
    with open("students.csv", "w", newline="") as f:   # newline="" avoids blank rows
        csv.writer(f).writerows(data)
    print("students.csv created.")
except IOError as e:
    print("Error:", e)
