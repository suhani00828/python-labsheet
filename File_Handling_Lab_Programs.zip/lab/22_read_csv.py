# Program 22: Read data from a CSV file and display it
import csv
try:
    with open("students.csv", "r") as f:
        for row in csv.reader(f):
            print(row)
except FileNotFoundError:
    print("File not found.")
