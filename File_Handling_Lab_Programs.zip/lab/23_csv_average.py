# Program 23: Calculate the average of numeric columns in a CSV file
import csv
try:
    with open("students.csv", "r") as f:
        rows = list(csv.DictReader(f))       # each row as a dictionary
    for col in rows[0].keys():
        try:
            values = [float(r[col]) for r in rows]   # fails for text columns
            print(f"Average of {col}: {sum(values) / len(values):.2f}")
        except ValueError:
            pass                                      # skip non-numeric columns
except FileNotFoundError:
    print("File not found.")
