# Program 24: Count the number of rows and columns in a CSV file
import csv
try:
    with open("students.csv", "r") as f:
        rows = list(csv.reader(f))
    print("Rows (incl. header):", len(rows))
    print("Columns            :", len(rows[0]))
except FileNotFoundError:
    print("File not found.")
