# Program 25: Append a new record to an existing CSV file
import csv
name = input("Name : ")
roll = input("Roll : ")
marks = input("Marks: ")
age = input("Age  : ")
try:
    with open("students.csv", "a", newline="") as f:   # append mode
        csv.writer(f).writerow([name, roll, marks, age])
    print("Record added.")
except IOError as e:
    print("Error:", e)
