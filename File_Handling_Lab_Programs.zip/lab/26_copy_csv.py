# Program 26: Copy data from one CSV file to another
import csv
try:
    with open("students.csv", "r") as src, open("copy_of_students.csv", "w", newline="") as dst:
        csv.writer(dst).writerows(csv.reader(src))   # copy row by row
    print("Data copied to copy_of_students.csv")
except FileNotFoundError:
    print("Source file not found.")
