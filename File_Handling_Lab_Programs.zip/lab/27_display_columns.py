# Program 27: Display specific columns (Name and Marks) from a CSV file
import csv
try:
    with open("students.csv", "r") as f:
        for row in csv.DictReader(f):
            print(f"{row['Name']:<10} {row['Marks']}")
except FileNotFoundError:
    print("File not found.")
except KeyError as e:
    print("Column not found:", e)
