# Program 28: Find and display the highest marks from a CSV file
import csv
try:
    with open("students.csv", "r") as f:
        rows = list(csv.DictReader(f))
    top = max(int(r["Marks"]) for r in rows)         # highest marks
    print("Highest marks:", top)
    for r in rows:                                    # show all students with that mark
        if int(r["Marks"]) == top:
            print("Student:", r["Name"])
except FileNotFoundError:
    print("File not found.")
