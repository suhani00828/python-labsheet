# Program 29: Search a record in a CSV file based on student name
import csv
name = input("Enter student name: ").strip().lower()
try:
    found = False
    with open("students.csv", "r") as f:
        for row in csv.DictReader(f):
            if row["Name"].lower() == name:
                print("Record found:", row)
                found = True
    if not found:
        print("Record not found.")
except FileNotFoundError:
    print("File not found.")
