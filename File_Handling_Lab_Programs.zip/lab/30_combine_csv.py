# Program 30: Combine multiple CSV files into one single file
import csv
files = ["class_a.csv", "class_b.csv"]
try:
    with open("combined.csv", "w", newline="") as out:
        writer = csv.writer(out)
        for i, name in enumerate(files):
            with open(name, "r") as f:
                rows = list(csv.reader(f))
                writer.writerows(rows if i == 0 else rows[1:])   # write header only once
    print("Combined into combined.csv")
except FileNotFoundError as e:
    print("File not found:", e)
